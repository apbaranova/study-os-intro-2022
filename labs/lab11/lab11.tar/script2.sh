#!/bin/bash
echo "Enter value: "
head -1
