#!/bin/bash
mkdir ~/backup
cp script.sh ~/backup/backup.sh
gzip ~/backup/backup.sh
